#Web Dev Assignments-

> Snake Game : https://codlocker.github.io/Small-Projects/Snake_FOoDie/Welcome.html

> JSON based Order-Tracker: https://codlocker.github.io/Small-Projects/orderTrack/index.html

> UI Design Styles: https://codlocker.github.io/Small-Projects/UI_Design/index.html
